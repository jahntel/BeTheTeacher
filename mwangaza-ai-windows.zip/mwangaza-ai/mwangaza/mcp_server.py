"""Custom MCP server exposing evidence and profile actions."""
from mcp.server.fastmcp import FastMCP
from . import store

mcp = FastMCP('mwangaza-learner-tools')

@mcp.tool()
def add_learning_evidence(learner_id: str, occurred_at: str, term: str, subject: str,
    evidence_type: str, title: str, observation: str, source_ref: str,
    score: float | None = None, max_score: float | None = None) -> dict:
    """Validate and store a sourced quiz, assignment, project, or teacher observation."""
    return store.add_evidence({'learner_id':learner_id,'occurred_at':occurred_at,'term':term,'subject':subject,
      'evidence_type':evidence_type,'title':title,'observation':observation,'source_ref':source_ref,
      'score':score,'max_score':max_score})

@mcp.tool()
def build_learner_profile(learner_id: str) -> dict:
    """Build a draft longitudinal profile from source-linked evidence; never make a pathway decision."""
    return store.build_profile(learner_id)

@mcp.tool()
def flag_pattern_for_review(learner_id: str, pattern: str, rationale: str, evidence_ids: list[str]) -> dict:
    """Create a pending teacher-review task. This does not share data with a guardian."""
    return store.flag_review(learner_id,pattern,rationale,evidence_ids)

@mcp.tool()
def get_learner_timeline(learner_id: str) -> list[dict]:
    """Retrieve chronological evidence for one learner."""
    return store.list_evidence(learner_id)

@mcp.resource('mwangaza://policy/human-approval')
def human_approval_policy() -> str:
    """Safety policy for consequential learner-profile actions."""
    return ('Profiles are drafts. Every pattern must cite evidence IDs. Never rank learners, diagnose, '
      'assign a pathway, or share guardian-facing information automatically. A named teacher must review '
      'and approve any consequential communication. Use synthetic data in this prototype.')

if __name__=='__main__':
    store.init_db()
    mcp.run()
