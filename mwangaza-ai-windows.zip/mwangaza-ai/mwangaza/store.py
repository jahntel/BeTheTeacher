"""Persistence and deterministic, evidence-grounded profile logic."""
from __future__ import annotations
import json, os, sqlite3, uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent.parent
DB_PATH = Path(os.environ.get('MWANGAZA_DB', ROOT / 'mwangaza.db'))

def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec='seconds')

def connect() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(DB_PATH, timeout=10)
    con.row_factory = sqlite3.Row
    con.execute('PRAGMA foreign_keys=ON')
    return con

def init_db() -> None:
    with connect() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS learners (
          learner_id TEXT PRIMARY KEY, display_name TEXT NOT NULL, grade TEXT NOT NULL, created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS evidence (
          evidence_id TEXT PRIMARY KEY, learner_id TEXT NOT NULL, occurred_at TEXT NOT NULL,
          term TEXT NOT NULL, subject TEXT NOT NULL, evidence_type TEXT NOT NULL,
          title TEXT NOT NULL, score REAL, max_score REAL, observation TEXT NOT NULL,
          source_ref TEXT NOT NULL, created_at TEXT NOT NULL,
          FOREIGN KEY(learner_id) REFERENCES learners(learner_id)
        );
        CREATE TABLE IF NOT EXISTS profiles (
          profile_id TEXT PRIMARY KEY, learner_id TEXT NOT NULL, created_at TEXT NOT NULL,
          summary TEXT NOT NULL, patterns_json TEXT NOT NULL, evidence_ids_json TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'draft', version INTEGER NOT NULL,
          FOREIGN KEY(learner_id) REFERENCES learners(learner_id)
        );
        CREATE TABLE IF NOT EXISTS review_tasks (
          task_id TEXT PRIMARY KEY, learner_id TEXT NOT NULL, created_at TEXT NOT NULL,
          pattern TEXT NOT NULL, rationale TEXT NOT NULL, evidence_ids_json TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'pending', reviewer TEXT, decision_note TEXT, decided_at TEXT,
          FOREIGN KEY(learner_id) REFERENCES learners(learner_id)
        );
        CREATE TABLE IF NOT EXISTS audit_log (
          audit_id TEXT PRIMARY KEY, timestamp TEXT NOT NULL, actor TEXT NOT NULL,
          action TEXT NOT NULL, input_json TEXT NOT NULL, output_json TEXT NOT NULL, result TEXT NOT NULL
        );
        ''')

def audit(action: str, inputs: Any, output: Any, result: str='success', actor: str='system') -> None:
    init_db()
    with connect() as c:
        c.execute('INSERT INTO audit_log VALUES (?,?,?,?,?,?,?)',
          (str(uuid.uuid4()), now(), actor, action, json.dumps(inputs, ensure_ascii=False, default=str),
           json.dumps(output, ensure_ascii=False, default=str), result))

def seed_demo() -> None:
    init_db()
    learners = [('K-104','Demo learner K-104','Grade 6'), ('K-208','Demo learner K-208','Grade 5')]
    with connect() as c:
        for lid, name, grade in learners:
            c.execute('INSERT OR IGNORE INTO learners VALUES (?,?,?,?)', (lid,name,grade,now()))
    sample = [
      ('K-104','2024-05-10','Grade 4 · Term 2','Mathematics','quiz','Geometry quiz',17,20,'Identified and compared 2D shapes accurately.','Q-G4-T2-014'),
      ('K-104','2025-08-14','Grade 5 · Term 2','Mathematics','assignment','Shapes assignment',18,20,'Correctly classified shapes and explained properties.','A-G5-T2-205'),
      ('K-104','2025-10-22','Grade 5 · Term 3','English','quiz','Reading comprehension',9,20,'Missed several inference questions; needs teacher context.','Q-G5-T3-318'),
      ('K-104','2026-02-12','Grade 6 · Term 1','English','quiz','Reading comprehension',10,20,'Literal questions stronger than inference questions.','Q-G6-T1-411'),
      ('K-208','2025-03-20','Grade 5 · Term 1','Science','project','Plant growth project',16,20,'Recorded observations and explained changes over time.','P-G5-T1-120'),
      ('K-208','2025-08-16','Grade 5 · Term 2','Science','assignment','Ecosystems worksheet',15,20,'Connected living things to their environments.','A-G5-T2-229'),
    ]
    with connect() as c:
        for row in sample:
            lid,date,term,subject,typ,title,score,max_score,obs,src = row
            c.execute('''INSERT OR IGNORE INTO evidence VALUES (?,?,?,?,?,?,?,?,?,?,?,?)''',
             (src,lid,date,term,subject,typ,title,score,max_score,obs,src,now()))
    audit('seed_demo', {'learners':len(learners)}, {'status':'synthetic records available'}, actor='setup')

def list_learners() -> list[dict]:
    init_db()
    with connect() as c: return [dict(r) for r in c.execute('SELECT * FROM learners ORDER BY learner_id')]

def list_evidence(learner_id: str | None=None) -> list[dict]:
    init_db()
    with connect() as c:
        if learner_id:
            rows=c.execute('SELECT * FROM evidence WHERE learner_id=? ORDER BY occurred_at, evidence_id',(learner_id,))
        else: rows=c.execute('SELECT * FROM evidence ORDER BY occurred_at DESC')
        return [dict(r) for r in rows]

def add_evidence(payload: dict, actor: str='agent') -> dict:
    required=['learner_id','occurred_at','term','subject','evidence_type','title','observation','source_ref']
    missing=[k for k in required if not str(payload.get(k,'')).strip()]
    if missing: raise ValueError('Missing required fields: '+', '.join(missing))
    lid=str(payload['learner_id']).strip()
    init_db()
    with connect() as c:
        if not c.execute('SELECT 1 FROM learners WHERE learner_id=?',(lid,)).fetchone():
            raise ValueError('Unknown learner_id; create/seed the learner before adding evidence.')
        score=payload.get('score'); maximum=payload.get('max_score')
        if score is not None or maximum is not None:
            if score is None or maximum is None or float(maximum)<=0 or float(score)<0 or float(score)>float(maximum):
                raise ValueError('score and max_score must be supplied together; score must be between 0 and max_score')
        eid=str(payload.get('evidence_id') or 'EV-'+uuid.uuid4().hex[:10].upper())
        c.execute('INSERT INTO evidence VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',
          (eid,lid,str(payload['occurred_at']),str(payload['term']),str(payload['subject']),str(payload['evidence_type']),
           str(payload['title']),score,maximum,str(payload['observation']),str(payload['source_ref']),now()))
    out={'evidence_id':eid,'learner_id':lid,'source_ref':payload['source_ref'],'status':'stored'}
    audit('add_learning_evidence',payload,out,actor=actor)
    return out

def build_profile(learner_id: str, actor: str='agent') -> dict:
    init_db(); ev=list_evidence(learner_id)
    if not ev: raise ValueError('No evidence found for learner.')
    by_subject: dict[str,list[dict]]={}
    for e in ev: by_subject.setdefault(e['subject'],[]).append(e)
    patterns=[]
    for subject, items in by_subject.items():
        scored=[x for x in items if x['score'] is not None and x['max_score']]
        if len(scored)>=2:
            vals=[round(100*x['score']/x['max_score'],1) for x in scored]
            ids=[x['evidence_id'] for x in scored]
            if len(vals)>=3 and all(v>=75 for v in vals[-3:]):
                patterns.append({'type':'possible_strength','subject':subject,'statement':f'Results were at least 75% across the last {min(3,len(vals))} scored records.','evidence_ids':ids[-3:],'confidence':'descriptive','needs_teacher_review':True})
            if len(vals)>=2 and all(v<60 for v in vals[-2:]):
                patterns.append({'type':'possible_support_need','subject':subject,'statement':'The two most recent scored records were below 60%; check context before interpreting.','evidence_ids':ids[-2:],'confidence':'descriptive','needs_teacher_review':True})
            if len(vals)>=2 and vals[-1]-vals[0]>=15:
                patterns.append({'type':'change_over_time','subject':subject,'statement':f'Scores changed by {vals[-1]-vals[0]:+.1f} percentage points across available scored records.','evidence_ids':ids,'confidence':'descriptive','needs_teacher_review':True})
    evidence_ids=[x['evidence_id'] for x in ev]
    if not patterns:
        patterns=[{'type':'insufficient_pattern','subject':'Across records','statement':'Available evidence does not yet meet the prototype’s pattern thresholds. More context or future records may be needed.','evidence_ids':evidence_ids,'confidence':'low','needs_teacher_review':True}]
    summary=f"Draft profile based on {len(ev)} evidence records across {len(set(x['term'] for x in ev))} recorded term/grade labels. {len(patterns)} descriptive pattern(s) require teacher interpretation. This is not a diagnosis or pathway decision."
    with connect() as c:
        previous=c.execute('SELECT MAX(version) v FROM profiles WHERE learner_id=?',(learner_id,)).fetchone()['v'] or 0
        pid='PR-'+uuid.uuid4().hex[:10].upper()
        c.execute('INSERT INTO profiles VALUES (?,?,?,?,?,?,?,?)',(pid,learner_id,now(),summary,json.dumps(patterns),json.dumps(evidence_ids),'draft',previous+1))
    out={'profile_id':pid,'learner_id':learner_id,'version':previous+1,'summary':summary,'patterns':patterns,'evidence_ids':evidence_ids,'status':'draft'}
    audit('build_learner_profile',{'learner_id':learner_id},{'profile_id':pid,'pattern_count':len(patterns),'evidence_ids':evidence_ids},actor=actor)
    return out

def flag_review(learner_id: str, pattern: str, rationale: str, evidence_ids: list[str], actor: str='agent') -> dict:
    if not pattern.strip() or not rationale.strip() or not evidence_ids: raise ValueError('Pattern, rationale, and evidence_ids are required.')
    init_db()
    with connect() as c:
        known={r['evidence_id'] for r in c.execute('SELECT evidence_id FROM evidence WHERE learner_id=?',(learner_id,))}
        unknown=set(evidence_ids)-known
        if unknown: raise ValueError('Evidence does not belong to learner or does not exist: '+', '.join(sorted(unknown)))
        tid='RV-'+uuid.uuid4().hex[:10].upper()
        c.execute('INSERT INTO review_tasks (task_id,learner_id,created_at,pattern,rationale,evidence_ids_json,status) VALUES (?,?,?,?,?,?,?)',
          (tid,learner_id,now(),pattern,rationale,json.dumps(evidence_ids),'pending'))
    out={'task_id':tid,'learner_id':learner_id,'status':'pending','evidence_ids':evidence_ids}
    audit('flag_pattern_for_review',{'learner_id':learner_id,'pattern':pattern,'evidence_ids':evidence_ids},out,actor=actor)
    return out

def list_profiles(learner_id: str | None=None) -> list[dict]:
    init_db()
    with connect() as c:
        q='SELECT * FROM profiles'; args=()
        if learner_id: q+=' WHERE learner_id=?'; args=(learner_id,)
        q+=' ORDER BY created_at DESC'
        result=[]
        for r in c.execute(q,args):
            d=dict(r); d['patterns']=json.loads(d.pop('patterns_json')); d['evidence_ids']=json.loads(d.pop('evidence_ids_json')); result.append(d)
        return result

def list_reviews(status: str | None=None) -> list[dict]:
    init_db()
    with connect() as c:
        q='SELECT * FROM review_tasks'; args=()
        if status: q+=' WHERE status=?'; args=(status,)
        q+=' ORDER BY created_at DESC'
        out=[]
        for r in c.execute(q,args):
            d=dict(r); d['evidence_ids']=json.loads(d.pop('evidence_ids_json')); out.append(d)
        return out

def decide_review(task_id: str, reviewer: str, decision: str, note: str='') -> dict:
    if decision not in ('approved','rejected'): raise ValueError('Decision must be approved or rejected.')
    if not reviewer.strip(): raise ValueError('A named reviewer is required.')
    init_db()
    with connect() as c:
        row=c.execute('SELECT * FROM review_tasks WHERE task_id=?',(task_id,)).fetchone()
        if not row: raise ValueError('Review task not found.')
        if row['status']!='pending': raise ValueError('Review task already decided; decisions cannot be overwritten.')
        c.execute('UPDATE review_tasks SET status=?, reviewer=?, decision_note=?, decided_at=? WHERE task_id=?',
          (decision,reviewer.strip(),note,now(),task_id))
    out={'task_id':task_id,'status':decision,'reviewer':reviewer.strip(),'decision_note':note,'decided_at':now()}
    audit('human_review_decision',{'task_id':task_id,'decision':decision,'note':note},out,actor=reviewer.strip())
    return out

def list_audit(limit: int=100) -> list[dict]:
    init_db()
    with connect() as c: return [dict(r) for r in c.execute('SELECT * FROM audit_log ORDER BY timestamp DESC LIMIT ?', (max(1,min(int(limit),1000)),))]

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser(); p.add_argument('--seed',action='store_true'); args=p.parse_args()
    init_db()
    if args.seed: seed_demo(); print('Synthetic demo data seeded in',DB_PATH)
    else: print('Database initialized at',DB_PATH)
