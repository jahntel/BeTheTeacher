"""Mwangaza AI learner-profile prototype."""
