"""Optional Pydantic AI agent using local Ollama and the custom MCP server."""
from __future__ import annotations
import argparse, asyncio, os, sys, json
from pathlib import Path

async def run_agent(learner_id: str, evidence_file: str | None = None) -> str:
    try:
        from pydantic_ai import Agent
        from pydantic_ai.mcp import MCPServerStdio
        from pydantic_ai.models.openai import OpenAIChatModel
        from pydantic_ai.providers.openai import OpenAIProvider
    except ImportError as e:
        raise RuntimeError('Install requirements.txt first; Pydantic AI MCP integration is required.') from e

    model_name=os.environ.get('MWANGAZA_MODEL','qwen2.5:3b')
    provider=OpenAIProvider(base_url=os.environ.get('OLLAMA_BASE_URL','http://localhost:11434/v1'), api_key='ollama')
    model=OpenAIChatModel(model_name, provider=provider)
    project_root=Path(__file__).resolve().parent.parent
    server=MCPServerStdio('python',['-m','mwangaza.mcp_server'],cwd=str(project_root))
    agent=Agent(model, toolsets=[server], system_prompt=(
      'You are Mwangaza AI, a cautious education evidence assistant. Use MCP tools to retrieve the selected learner timeline and build a draft profile. '
      'Cite evidence IDs for every claim. Distinguish observed scores from interpretations, mention small samples and missing context, and never diagnose, rank learners, '
      'or assign a subject/career pathway. Do not approve guardian sharing; create a teacher review task for patterns only when there is source evidence. '
      'All output is a draft for a named teacher. Use the supplied learner ID only.'))
    prompt=f'For learner {learner_id}, retrieve their timeline, inspect longitudinal evidence, and build a draft profile using available MCP tools. '
    if evidence_file:
        path=Path(evidence_file)
        if not path.is_absolute(): path=project_root/path
        payload=json.loads(path.read_text(encoding='utf-8'))
        if payload.get('learner_id') != learner_id:
            raise ValueError('Evidence file learner_id must match --learner.')
        prompt += ('First call add_learning_evidence with every field from this synthetic evidence payload, then retrieve the timeline and build the updated draft profile. '
                   'Preserve the source_ref. Payload: ' + json.dumps(payload, ensure_ascii=False) + ' ')
    prompt += 'Return a concise teacher-facing report with patterns, citations, uncertainty, and tool actions performed. Do not flag a review task unless evidence warrants it.'
    async with server:
        result=await agent.run(prompt)
    return str(result.output)

def main():
    p=argparse.ArgumentParser(); p.add_argument('--learner',required=True); p.add_argument('--evidence-file'); args=p.parse_args()
    try: print(asyncio.run(run_agent(args.learner,args.evidence_file)))
    except Exception as e:
        print(f'Agent run failed: {e}',file=sys.stderr)
        print('Check Ollama is running, the model is pulled, dependencies are installed, and Pydantic AI MCP APIs match your installed version.',file=sys.stderr)
        raise SystemExit(1)
if __name__=='__main__': main()
