# Implementation status and submission honesty

## Implemented in source
- SQLite schema for synthetic learners, evidence, versioned draft profiles, review tasks, and audit logs.
- Evidence validation, source references, learner-specific evidence checks, deterministic descriptive profile patterns.
- Custom FastMCP server with four tools and one policy resource.
- Streamlit dashboard with profile, timeline, add-evidence, review, and audit tabs.
- Named-reviewer decision flow with immutable first decision.
- Pydantic AI agent entry point configured for local Qwen through Ollama and the custom MCP stdio server.
- Borrowed filesystem MCP server launch instructions restricted to synthetic `data` directory.
- Unit tests and eight-plus evaluation cases.

## Must be run/verified on the developer's Windows machine
- Python dependency installation and Streamlit startup.
- Local Ollama installation/model pull and a successful end-to-end Pydantic AI + MCP call.
- Borrowed filesystem MCP process startup (requires Node.js/npm).
- Unit test results and evaluation table outcomes.
- Public GitHub repository, public video, and final submission form.

## Not production-ready
Authentication, school roles, encrypted storage, tamper-resistant audit storage, backups, data retention, guardian notification integration, and legal/privacy review are not implemented. Do not use real student records or expose the app publicly.
