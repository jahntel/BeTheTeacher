import os, tempfile, unittest
from pathlib import Path

class StoreTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory()
        os.environ['MWANGAZA_DB']=str(Path(cls.tmp.name)/'test.db')
        from mwangaza import store
        cls.store=store
        store.init_db(); store.seed_demo()
    @classmethod
    def tearDownClass(cls): cls.tmp.cleanup()
    def test_seed_creates_demo_evidence(self):
        self.assertGreaterEqual(len(self.store.list_learners()),2)
        self.assertGreaterEqual(len(self.store.list_evidence('K-104')),4)
    def test_add_valid_evidence(self):
        out=self.store.add_evidence({'learner_id':'K-104','occurred_at':'2026-10-14','term':'Grade 6 T2','subject':'Maths','evidence_type':'quiz','title':'test','score':8,'max_score':10,'observation':'synthetic','source_ref':'TEST-ADD'},actor='test')
        self.assertEqual(out['status'],'stored')
        self.assertIn(out['evidence_id'],[x['evidence_id'] for x in self.store.list_evidence('K-104')])
    def test_unknown_learner_rejected(self):
        with self.assertRaises(ValueError): self.store.add_evidence({'learner_id':'NOPE','occurred_at':'2026-01-01','term':'T1','subject':'Math','evidence_type':'quiz','title':'x','observation':'x','source_ref':'x'})
    def test_invalid_score_rejected(self):
        with self.assertRaises(ValueError): self.store.add_evidence({'learner_id':'K-104','occurred_at':'2026-01-01','term':'T1','subject':'Math','evidence_type':'quiz','title':'x','score':11,'max_score':10,'observation':'x','source_ref':'x'})
    def test_profile_cites_evidence(self):
        p=self.store.build_profile('K-104',actor='test')
        self.assertTrue(p['evidence_ids']); self.assertTrue(p['patterns'])
        self.assertTrue(all('evidence_ids' in x for x in p['patterns']))
    def test_review_rejects_unknown_evidence(self):
        with self.assertRaises(ValueError): self.store.flag_review('K-104','pattern','why',['NO-SUCH-ID'])
    def test_named_reviewer_required(self):
        task=self.store.flag_review('K-104','test pattern','test rationale',[self.store.list_evidence('K-104')[0]['evidence_id']],actor='test')
        with self.assertRaises(ValueError): self.store.decide_review(task['task_id'],'','approved')
    def test_decision_cannot_be_overwritten(self):
        task=self.store.flag_review('K-104','test pattern 2','test rationale',[self.store.list_evidence('K-104')[0]['evidence_id']],actor='test')
        self.store.decide_review(task['task_id'],'Teacher Example','approved','reviewed')
        with self.assertRaises(ValueError): self.store.decide_review(task['task_id'],'Teacher Example','rejected','overwrite')
    def test_audit_logs_mutations(self):
        logs=self.store.list_audit()
        self.assertTrue(any(x['action']=='add_learning_evidence' for x in logs))
        self.assertTrue(all(x['timestamp'] and x['input_json'] and x['output_json'] for x in logs))

if __name__=='__main__': unittest.main()
